<?  $currentPage="contact";
    include_once "includes/header.php"; ?>
<body>
    <!-- NAVBAR -->
    <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><?php echo $nume; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarScroll">
                <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                <?php
                        foreach ($navbar as $key => $value) {
                            echo "<li class='nav-item'>
                                    <a class='nav-link' href='$value'>$key</a>
                                
                                </li>";
                        }
                        ?>
                </ul>
                <?include "includes/search-form.php";?>
            </div>
            </div>
        </nav>

        <!-- NAVBAR END-->
        
            <div class="container">
                <h1>Contact</h1>
                Contact information
            </div>
    </div>


    <?include_once "includes/footer.php"; ?>