<? require_once('includes/header.php'); 
   require_once('includes/navbar.php');?>
    <? if(isset($_GET['s']) && strlen($_GET['s']) >=3) {
        $s = $_GET['s']; ?>
        <h1>Search results for: <? echo $s; ?></h1>
        <?include("includes/search-form.php");?>
        <? $movies = array_filter($movies, 'find_by_movie_title');
            if(count($movies) === 0) {
            ?>
                <p> No results </p>
                <? include('includes/search-form.php'); ?>
            <? } else { ?>
                <div class = "row movies-list">
                    <? foreach($movies as $movie) 
                        require('includes/archive-movie.php');
                    ?>
                </div>
            <? } ?>
    <?php } elseif(isset($_GET['s']) && strlen($GET['s']) <3){ ?>
        <h1>Search term must be at least 3 characters long</h1>
        <p> Try something else </p>
        <? include('includes/search-form.php'); ?>
    <?php } else { ?>
        <h1>Invalid search</h1>
        <p> Try something else </p>
        <? include('includes/search-form.php'); ?>
    <?php } ?>
<? require_once('includes/footer.php'); ?>

                    
        
        