<?  $currentPage = "index.php"; 
    include_once "includes/header.php"; ?>
<body>

    <? include_once "includes/navbar.php";?>
        
            <div class="container">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic aliquam nisi ratione tempore voluptates est modi fuga voluptas et veniam, dolor,Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas maxime eum, cupiditate repellat incidunt recusandae laudantium odio quia. Eos iure itaque, quibusdam maiores perspiciatis fugit necessitatibus. Officiis eligendi cum quidem.lor
            </div>
    </div>
    <?include_once "includes/footer.php"; ?>






   