<?  $currentPage = "movie.php";
    
    include_once "includes/header.php";
    include_once "includes/navbar.php"; 
    ?>

    <? $movie_id = $_GET['movie_id']; 
    $movies_filtered=(array_filter($movies, 'find_by_movie_id'));
    $movie = reset($movies_filtered);?>
    <div class="col-auto">
        <?
                                
        $fav_movies=array();  
        $fav_stats = array();
            if(isset($_COOKIE["fav_movies"])){
                $fav_movies= json_decode($_COOKIE["fav_movies"],true);
            }
            if(isset($_POST["fav"])){ 
                 if($_POST["fav"]==="1" && !in_array($_GET['movie_id'], $fav_movies )){
                    $fav_movies[]= $_GET["movie_id"];
                 if(array_key_exists($_GET['movie_id'], $fav_stats)){
                        $fav_stats[$_GET['movie_id']]++;
                            }else{
                                $fav_stats[$_GET['movie_id']]=1;
                                }
                        setcookie("fav_movies", json_encode($fav_movies), time() + (86400 * 30 * 12));
                    }elseif($_POST["fav"]==="0" && in_array($_GET['movie_id'], $fav_movies )){
                            if(($key = array_search($_GET['movie_id'], $fav_movies)) !== false) {
                                unset($fav_movies[$key]);
                                setcookie("fav_movies", json_encode($fav_movies), time() + (86400 * 30 * 12));
                                    if(array_key_exists($_GET['movie_id'], $fav_stats)){
                                        $fav_stats[$_GET['movie_id']]++;
                                    }else{
                                        $fav_stats[$_GET['movie_id']]=1;
                                        }
                        } 
                                    }
                                    file_put_contents("fav_stats.json", json_encode($fav_stats));
                                    
                                }
                            
                                ?>
                                
                    </div>
    
  
    
    <div class="container ">
                <h1><? echo $movie['title']; ?></h1>
                    <div class="row">
                   <div class="col-md-4 col-lg-3 mb-3">
                    <div class="poster-bg-img"style="background-image:url(<? echo $movie['posterUrl']; ?>"></div>
                   </div>
                   <div class="col-md-8 col-lg-9">
                       <div class="row justify-content-between">
                           <div class="col-6 ">
                                <div class="h4 fw-bold">Release Year: <? echo $movie['year']; ?> </div>
                           </div>
                            <div class="col-6">
                                <form action="" method="POST" >
                                        <input name="fav" type="hidden" value="<?echo (in_array($_GET['movie_id'], $fav_movies)) ? "0" : "1" ; ?>">
                                        <button type="submit" class="btn btn-primary position-relative <?echo (in_array($_GET['movie_id'], $fav_movies)) ? "btn-danger" : "btn-success" ; ?>"> <?echo (in_array($_GET['movie_id'], $fav_movies)) ? "Sterge din Favorite" : "Add to favourites" ; ?>
                                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><? echo (isset($fav_stats[$_GET['movie_id']])) ? $fav_stats[$_GET['movie_id']] : 0; ?> </span>
                                        <span class="visually-hidden"></span> 
                                    </button>
                                    </form>
                            </div>
                       </div>
                                <?check_old_movie($movie['year']) ?></div>
                            <div class="mt-4 mb-8">
                                Plot: <? echo $movie['plot']; ?>
                            </div>
                            <div class="mt-4 mb-8">
                                Directed By: <? echo $movie['director']; ?>
                            </div>
                            <div class="mt-4 mb-8">
                                Runtime: <?echo runtime_prettier($movie['runtime'])?>
                            </div>
                            <div class="h5 mt-4 mb-8"></div>
                                Cast:
                                <ul>
                                    <li> <? $actors = explode(',',$movie['actors']);
                                            echo '<ul>';
                                            foreach($actors as $actor){
                                                echo '<li>'.$actor.'</li>';
                                            }
                                            echo '</ul>'; ?></li>
                                </ul>            
                            </div>
                            
                            <? include_once "includes/movie-reviews.php"; ?>
                    </div> 
        </div>
                
    
    <? include_once "includes/footer.php"; ?>
            
                    