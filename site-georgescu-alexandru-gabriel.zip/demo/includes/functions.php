<?php


function runtime_prettier($time, $format = '%02d hours %02d minutes') {
    
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
};
function check_old_movie($year) {
    if($year < 2000) { ?>
        <div class="alert alert-danger" role="alert">
            <strong>Oh snap!</strong> This movie is old.
    <? } else { ?>
        <div class="alert alert-success" role="alert">
            <strong>Well done!</strong> This movie is new.
        </div>
    <? }
};
function hello_time_of_day() {
    $hour = date('H');
    if ($hour < 12) {
        return 'morning';
    } elseif ($hour < 18) {
        return 'afternoon';
    } else {
        return 'evening';
    }
};
function find_by_movie_id($item) {
    if(!isset($_GET['movie_id'])) 
        return false;
    
    if(intval($_GET['movie_id']) === $item['id']) {
        return true;
    }else{
            return false;
        }
    };
function find_by_movie_title($item) {
    if(stripos($item['title'], $_GET['s']) === false) {
        return false;
    }else{ 
        return true;
    }
};
function find_by_movie_year($item) {
    if(intval($_GET['year']) === $item['year']) {
        return true;
    }else{
            return false;
        }
    };
    function find_by_movie_director($item) {
    if(stripos($item['director'], $_GET['s']) === false) {
        return false;
    }else{
        return true;
    }
};
function find_by_movie_actors($item) {
    if(stripos($item['actors'], $_GET['s']) === false) {
        return false;
    }else{
        return true;
    }
};
function find_by_movie_genre($item) {
    if(stripos($item['genre'], $_GET['s']) === false) {
        return false;
    }else{
        return true;
    }
};
function db_connect($host = 'localhost', $username='php-user', $password='php-password', $dbname='php-proiect') {
    return mysqli_connect($host, $username, $password, $dbname);
}
