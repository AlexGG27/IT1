<?
    $conn=db_connect();
    $review_data =array(
        'show_revieqs_form' => false,
    );
    if(!$conn) {
        die('Connection failed: ' . mysqli_connect_error());
    }
    $sql = "CREATE TABLE IF NOT EXISTS reviews (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_id BIGINT(6) UNSIGNED NOT NULL,
        full_name tinytext NOT NULL,
        email varchar(100) NOT NULL,
        review TEXT NOT NULL,
    )";

    if (mysqli_query($conn, $sql)) {
        $sql = "SELECT full_name, email, review FROM reviews WHERE movie_id = " . $_GET['movie_id'];
        $reviews_list= mysqli_query($conn, $sql);

        $review_data['show_revieqs_form'] = true;
        $review_data['count'] = mysqli_num_rows($reviews_list);
        if($review_data['count'] > 0) {
            $review_data['reviews'] = mysqli_fetch_all($reviews_list, MYSQLI_ASSOC);
            $reviews_emails= array_column($review_data['reviews'], 'email');
        }

        if(isset($_POST['reviews_form'])) {
            $sql = "INSERT INTO reviews (movie_id, full_name, email, review) 
            VALUES (" . $_GET['movie_id'] . ", '" . $_POST['full_name'] . "', '" . $_POST['email'] . "', '" . $_POST['review'] . "')";
            
            if(mysqli_query($conn, $sql)) {
               $review_data['show_revieqs_form'] = false;
               $review_data['alert']='success';
                $review_data['message']='Formular adaugat cu success';
            }else{
                $review_data['alert']='danger';
                $review_data['message']='Formularul nu a putut fi adaugat';
            }
        }
    }

?>
<? if(isset($review_data['message'])){ ?>
    <div class="alert my-3 alert-<? echo $review_data['alert']; ?>" role='alert' >
        <? echo $review_data['message']; ?>
    </div>
<? } ?>


<? if( $review_data['show_revieqs_form'] == true){ ?>
    <div class='mb-3 pb-3 border-bottom'>
        <? if($review_data['count'] > 0) { 
            echo 'Lasa un review';
        }else{
            echo 'Nu exista review-uri inca. Fi primul!';
        } ?>
<form action="" method="POST">
  <div class="mb-3">
      <label for="full_name">Full Name</label>
      <input type="text" class="form-control" id="full_name" name = 'full_name' value="<?if(isset($_POST['full_name'])) echo $_POST['full_name']; ?> " placeholder="Full Name">
  </div>
  <div class="mb-3">
    <label for="email">Email address</label>
    <input type="email" class="form-control" id="email" name = 'email' value="<?if(isset($_POST['email'])) echo $_POST['email']; ?>" placeholder="name@example.com" required>
  </div>
  <div class="mb-3">
    <label for="review">Review</label>
    <textarea class="form-control" id="review" name= 'review' value="<?if(isset($_POST['review'])) echo $_POST['review']; ?> " placeholder="Write your review here." required></textarea>
  </div>
  <div class="mb-3">
    <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck">
        <label class="form-check-label" for="gridCheck">
            Esti de acord cu termenii si conditiile de utilizare.
        </label>
    </div>
   </div>
    <button type="submit" class="btn btn-primary mt-3" value = 'Trimite' name="reviews_form" required>Submit</button>
  </div>  

</form>

<? } ?> 
<? if(isset($review_data['count']) && $review_data['count'] > 0) { ?>
    <div class="h4 mt-4">
        Review-uri
    </div>
    <? foreach($review_data['reviews'] as $review) { ?>
        <div class="my-3 p3- border">
            <div class="fw-bold pb-3 mb-3 border-bottom">
                <? echo $review['full_name']; ?></h5>
                <? echo $review['review']; ?>
            </div>
        </div>
    <? } ?>
<? } ?>