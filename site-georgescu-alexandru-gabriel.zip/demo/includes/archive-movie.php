<div class='col-lg-4 col-md-6 mb-4'id="movie-<? echo $movie['id']; ?>" >
    <div class = "card">
       <div class="movie-poster card-img-top"
          style="background-image: url(<? echo $movie['posterUrl']; ?>);"
          alt="<? echo $movie['title']; ?>">
       </div>
       <div class="card-body">
           <h5 class="card-title"><? echo $movie['title']; ?></h5>
              <p class="card-text"><? echo substr($movie['plot'],0,100). '...'; ?></p>
              <a href="movie.php?movie_id=<? echo $movie['id']; ?>" class="btn btn-primary">More info</a> 
       </div>
    </div>
</div>      
            
                    
